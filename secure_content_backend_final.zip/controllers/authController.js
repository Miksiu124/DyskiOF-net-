exports.register = (req, res) => {/* handle registration */};
exports.login = (req, res) => {/* handle login */};
exports.discordOAuth = (req, res) => {/* handle Discord OAuth */};