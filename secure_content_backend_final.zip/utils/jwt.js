exports.signToken = (user) => {/* sign JWT */};
exports.verifyToken = (token) => {/* verify JWT */};